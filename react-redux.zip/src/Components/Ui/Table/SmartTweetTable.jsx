import React, { Component, PropTypes } from 'react';
import TweetTable from './TweetTable';
import { FETCH_TWEETS, onDeleteTweet } from '../../../Containers/About/Action';

class SmartTweetTable extends Component {

	constructor( props ) {

		super( props );
		const { tweets, actionType } = props;

		this.state = {
			tweets,
			actionType
		};

		this.deleteTweetClick = this.deleteTweetClick.bind( this );

	}


	// componentWillMount() {
	// 	console.log( 'SmartTweetTable mounting' );
	// }
	shouldComponentUpdate(nextProps, nextState){
		// console.log('shouldComponentUpdate', nextProps, nextState);
		// const { tweets } = nextProps;
		// this.setState( { tweets,});
		// this.state = {
		// 	tweets,
		// };
		// console.log(this.state);
		// console.log(this.props, nextProps);
		if(nextProps.actionType === FETCH_TWEETS) {
			return true;
		}else {
			return false;
		}
	}
	componentWillUnmount(){
		console.log('componentWillUnmount', this.props);
	}

	deleteTweetClick(id){
			console.log(" Delete call", id);
			return onDeleteTweet(id);
	}

	render(){
		console.log('render tweets ', this.state.tweets);
		return <TweetTable tweets={this.props.tweets} onDelete={this.deleteTweetClick}/>;
	}

}

export default SmartTweetTable;
