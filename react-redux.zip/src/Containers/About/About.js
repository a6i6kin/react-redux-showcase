import React, {Component} from 'react';
import {connect} from 'react-redux';
import {onTestAction, onFetchTweets, TEST_ACTION, FETCH_TWEETS} from './Action';
import Button from '../../Components/Ui/Button/Button';
import SmartTweetTable from '../../Components/Ui/Table/SmartTweetTable'

const mapStateToProps = (state, ownProps) => {

	console.log('mapStateToProps state: ', state);

	return {tweets: state.tweets || []};
};

let actionType = TEST_ACTION;
const mapDispatchToProps = (dispatch) => {

	// const testAction = dispatch(onTestAction(null, {type: 'any'}, false));

	const testAction = () => {
		dispatch(onTestAction(null, {buttonLabel: 'Changed with Reducer'}, false))
	};

	const getFeedsAction = () => {
		dispatch(onFetchTweets());
	};

	return {testAction, getFeedsAction};

};


class About extends Component {

	constructor(props) {
		super(props);

		this.onClickTest = this.onClickTest.bind(this);
		this.onLoadTweetsClick = this.onLoadTweetsClick.bind(this);
	}

	onClickTest = () => {
		this.actionType =TEST_ACTION;
		return this.props.testAction();
	};

	onLoadTweetsClick = () => {
		this.actionType = FETCH_TWEETS;
			return this.props.getFeedsAction();
	};

	render() {
		//console.log(Button);

		if(this.actionType === FETCH_TWEETS){
			return (
				<div>
					<Button label={this.props.buttonLabel} onClick={this.onClickTest}/>
					<SmartTweetTable tweets={this.props.tweets} actionType={this.actionType}/>
				</div>

			);
		}

		return (
			<div>
				<Button label="Load Tweets" onClick={this.onLoadTweetsClick}/>
				<ul>
					{this.props.tweets.map((key, val) => {
						return <li key={val}>{key.id} {key.text}</li>
					})}
				</ul>
			</div>

		);
	}

}

export default connect(mapStateToProps, mapDispatchToProps)(About);
